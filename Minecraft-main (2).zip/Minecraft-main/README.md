# Minecraft
Voxel Engine (like Minecraft) in Python and OpenGL 

Control: WASDQE + mouse

![minecraft](/screenshot/0.jpg)